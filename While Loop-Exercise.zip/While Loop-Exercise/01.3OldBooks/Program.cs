﻿using System;

namespace _01._3OldBooks
{
    class Program
    {
        static void Main(string[] args)
        {
            string bookToBeFound = Console.ReadLine();
            string currentBook = Console.ReadLine();
            bool isFound = false;
            int count = 0;

            while (currentBook != "No More Books")
            {
                if (bookToBeFound == currentBook)
                {
                    isFound = true;
                    break;
                }
                count++;
                currentBook = Console.ReadLine();
            }
            if (isFound)
            {
                Console.WriteLine($"You checked {count} books and found it.");
            }
            else
            {
                Console.WriteLine($"The book you search is not here!");
                Console.WriteLine($"You checked {count} books.");
            }
        }
    }
}
