﻿using System;

namespace _02._2ExamPreparation
{
    class Program
    {
        static void Main(string[] args)
        {
            int poorGradesLimit = int.Parse(Console.ReadLine());

            int badGradesCounter = 0;
            int gradesCounter = 0;
            string lastProblem = "";
            double sumOfGrades = 0;
            while (true)
            {
                string task = Console.ReadLine();
                if (task == "Enough")
                {
                    Console.WriteLine($"Average score: {sumOfGrades/gradesCounter:f2}");
                    Console.WriteLine($"Number of problems: {gradesCounter}");
                    Console.WriteLine($"Last problem: {lastProblem}");
                    break;
                }
                int grades = int.Parse(Console.ReadLine());

                if (grades <= 4.00)
                {
                    badGradesCounter++;
                }

                if (badGradesCounter >= poorGradesLimit)
                {
                    Console.WriteLine($"You need a break, {badGradesCounter} poor grades.");
                    break;
                }
                sumOfGrades += grades;
                gradesCounter++;
                lastProblem = task;
            }
        }
    }
}
